These modules are to be used with the 3.8.11 chromeos kernel
Look at the mountcifs script to see the usage.

Enjoy :)
